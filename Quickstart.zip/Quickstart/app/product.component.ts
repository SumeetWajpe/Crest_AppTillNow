
import {Component,Input} from '@angular/core';

@Component({
    selector:'product',
    template:`
    <h1> {{prodDetails.title   }} </h1>
    <img [src]="prodDetails.ImageUrl" height="100px" width="100px" /> 
    <br/>
           
    <b> Price :  </b> {{prodDetails.price  }} <br/>
    
    <b> Quantity :  </b> {{prodDetails.quantity}} <br/>
    
    <b> Rating :  </b> {{prodDetails.rating  }} <br/>
    <hr/> 
    `
  
})
export class ProductComponent{
    @Input()     prodDetails:any = {};
  
}

