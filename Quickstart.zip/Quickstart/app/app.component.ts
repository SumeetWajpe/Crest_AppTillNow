import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template:`<cart></cart>`
  // template: `
   
  // <ul >
  //       <li *ngFor="let c of courses">
  //         {{ c }}
  //       </li>
  // </ul>
    
  // `,
})
export class AppComponent  { 
  name = 'Angular';
  courses:string[] = ['ReactJS','MongoDB','NodeJS'];
  
 }
