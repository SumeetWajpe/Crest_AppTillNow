import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent }  from './app.component';
import {CourseComponent} from './course.component';
import {ProductComponent} from './product.component';
import {ShoppingCartComponent} from './shoppingcart.component';


@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ AppComponent,CourseComponent,ProductComponent,ShoppingCartComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
